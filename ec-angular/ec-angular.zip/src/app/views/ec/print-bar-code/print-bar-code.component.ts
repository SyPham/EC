import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-print-bar-code',
  templateUrl: './print-bar-code.component.html',
  styleUrls: ['./print-bar-code.component.css']
})
export class PrintBarCodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
