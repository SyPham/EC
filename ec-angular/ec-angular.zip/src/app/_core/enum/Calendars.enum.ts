export enum WeekDay {
    Monday= 'Monday',
    Tuesday= 'Tuesday',
    Wednesday= 'Wednesday',
    Thursday= 'Thursday',
    Friday= 'Friday',
    Saturday= 'Saturday',
    Sunday = 'Sunday'
    }
export const Months: number [] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
export const Quarterly: string [] = [
    'First quarter',
    'Second quarter',
    'Third quarter',
    'Fourth quarter'
  ];

export const DAYOFMONTH: string [] = ['First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Nighth',
'Tenth', 'Eleventh', 'Twelfth', 'Thirteenth', 'Fourteenth',
'Fifteenth', 'Sixteenth', 'Seventeenth', 'Eighteenth', 'NineTeenth',
'Twentieth', 'Twenty-first', 'Twenty-second', 'Twenty-third', 'Twenty-fourth', 'Twenty-fifth', 'Twenty-sixth', 'Twenty-seventh', 'Twenty-eight', 'Twenty-nineth', 'Thirtieth', 'Thirty-first'] ; 