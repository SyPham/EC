export interface IRole {
    ID: number;
    Name: string;
}
