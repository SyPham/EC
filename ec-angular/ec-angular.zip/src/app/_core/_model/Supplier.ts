export interface ISupplier {
    id: number;
    name: string;

}
