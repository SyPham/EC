export interface IPartname2 {
    id: number ;
    name: string;
}
