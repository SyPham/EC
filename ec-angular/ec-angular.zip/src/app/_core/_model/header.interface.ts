export interface IHeader {
    router: string;
    message: string;
}
