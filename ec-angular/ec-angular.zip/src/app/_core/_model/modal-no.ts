export interface ModalNo {
    id: number;
    name: string;
    modelNameID: number;
    modelName: string;
}
