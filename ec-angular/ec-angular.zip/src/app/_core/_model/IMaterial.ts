export interface IMaterial  {
    id: number;
    name: string;
}
