export interface Line {
    id: number;
    name: string;
}
