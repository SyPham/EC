import { DateTime } from '@syncfusion/ej2-angular-charts';

export interface ICommentModelName  {
    id: number;
    content: string;
    BPFCEstablishID: number;
    createdByName: string;
    createdDate: Date;
    createdBy: number;

}