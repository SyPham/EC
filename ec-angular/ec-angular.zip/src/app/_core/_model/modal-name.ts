export interface ModalName {
    id: number;
    name: string;
    modelNo: string;
    createdBy: number;
}

