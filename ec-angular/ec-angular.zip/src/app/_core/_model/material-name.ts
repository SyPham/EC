export interface IMaterialName {
    id: number ;
    name: string;
}
