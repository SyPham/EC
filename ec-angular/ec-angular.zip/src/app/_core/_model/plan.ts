export interface Plan {
    id: number;
    buildingID: number;
    hourlyOutput: number;
    workingHour: number;
    BPFCEstablishID: number;
    dueDate: any;
}
