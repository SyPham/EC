export interface IArticleNo {
    id: number;
    name: string;
    modelNameID: number;
}
