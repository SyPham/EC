export interface IPartname {
    id: number ;
    name: string;
}
