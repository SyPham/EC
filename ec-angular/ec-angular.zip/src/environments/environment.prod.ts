export const environment = {
  production: true,
  apiUrlEC: 'http://10.4.4.224:1001/api/',
  apiUrl: 'http://10.4.4.224:106/api/',
  hub: 'http://10.4.4.224:1001/ec-hub'
};
